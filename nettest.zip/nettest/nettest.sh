#!/bin/bash
java -jar NetTest.jar $1 $2
